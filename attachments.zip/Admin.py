# Admin Module
import mysql.connector

def addQuestion():
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
    cur = mydb.cursor()
    query = "Select Max(Qno) From Paper"
    cur.execute(query)
    data = cur.fetchall()
    qno = int(data[0][0]) + 1
    while True:
        print("Question No. : ",qno)
        ques = input("Enter the Question : ")
        opt1 = input("Enter Option 1     : ")
        opt2 = input("Enter Option 2     : ")
        opt3 = input("Enter Option 3     : ")
        opt4 = input("Enter Option 4     : ")
        ans  = input("Enter Answer       : ")
        query = "Insert Into Paper Values("+str(qno)+",'"+ques+"','"+opt1+"','"+opt2+"','"+opt3+"','"+opt4+"',"+ans+")"
        cur.execute(query)
        mydb.commit()
        print("Question Insert Successfully !!!")
        ch = input("Add More Question? (y/n) : ")
        if ch in "nN":
            break
        else:
            qno += 1
    
def searchQuestion():
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='cet')
    mycursor = mydb.cursor()

    Qno = input("Enter Question Number to be search : ")
    query = "Select * From Paper Where Qno = "+Qno
    mycursor.execute(query)
    data = mycursor.fetchall()
    
    if data == []:  
        print("Record not Found !")
    else:
        print("Question    : ",data[0][1])
        print("Option 1    : ", data[0][2])
        print("option 2    : ",data[0][3])
        print("option 3    : ",data[0][4])
        print("option 4    : ", data[0][5])
        print("Correct ans : ",data[0][6])

def updateQuestion():
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='cet')
    mycursor = mydb.cursor()

    Qno = input("Enter Question Number to be update : ")
    query = "Select * From Paper Where Qno = "+Qno

    mycursor.execute(query)
    data = mycursor.fetchall()

    found = False
    if data == []:
        print("Record not Found !")
    else:
        Ques = str(data[0][1])
        option1 =str(data[0][2])
        option2 = str(data[0][3])
        option3 = str(data[0][4])
        option4 = str(data[0][5])
        Cans = str(data[0][6])
        found = True

    if found:
        while True:
            print("Question    : ",Ques)
            print("Option 1    : ",option1)
            print("Option 2    : ",option2)
            print("Option 3    : ",option3)
            print("Option 4    : ",option4)
            print("Correct ans : ",Cans)
            print("Edit : 1.Question 2.Option 1 3.Option 2 4.Option 3 5.Option 4 6.Correct ans 7.No more Edit ")
            ch = int(input("Enter the choice : "))
            if ch == 1:
                Ques = input("Enter the Ques : ")
            elif ch == 2:
                option1 = input("Enter Option 1 : ")
            elif ch == 3:
                option2 = input("Enter Option 2 : ")
            elif ch == 4:
                option3 = input("Enter Option 3 : ")
            elif ch == 5:
                option4 = input("Enter Option 4 : ")
            elif ch == 6:
                Cans = input("Enter the correct ans : ")
            elif ch == 7:
                break
            else:
                print("Invalid Choice !!!")
        query = "Update Paper Set Question='"+Ques+"', Option1 ='"+option1+"', Option2 ='"+option2
        query +="', Option3='"+option3+"', Option4 = '"+option4+"', Answer ="+Cans
        query += " Where Qno = "+Qno
        mycursor.execute(query)
        mydb.commit()

def deleteQuestion():
    mydb = mysql.connector.connect(host='localhost', user='root',passwd='',database='cet')
    mycursor = mydb.cursor()

    Qno = input("Enter Question Number to be delete in the record : ")
    query = "Select * From Paper Where Qno="+Qno
    mycursor.execute(query)
    data = mycursor.fetchall()
    if data == []:
        print("Record not Found !!!")
    else:
        print("Question No : ",data[0][0])
        print("Question    : ",data[0][1])
        print("Option 1    : ",data[0][2])
        print("Option 2    : ",data[0][3])
        print("Option 3    : ",data[0][4])
        print("Option 4    : ",data[0][5])
        print("Correct ans : ",data[0][6])
        ch = input("Are you want to sure delete this record? (y/n) : ")
        if ch in "yY":
            query = "Delete From Paper Where Qno="+Qno
            mycursor.execute(query)
            mydb.commit()
            print("Delete Successfully !")
        else:
            print("Record can not be deleted !")
    
def showMS():
    mydb = mysql.connector.connect(host='localhost', user='root',passwd='',database='cet')
    mycursor = mydb.cursor()
    query = "Select * From Paper"
    mycursor.execute(query)

    data = mycursor.fetchall()
    for d in data:
        print("Qno : ",d[0],end="\t")
        print(" Answer : Option",d[6])
        
   
    
