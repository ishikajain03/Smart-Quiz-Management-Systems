# Main Module

from Admin import *
from Student import *
from Exam import *
import mysql.connector

def Password():
    uid = input("User ID  : ")
    p = input("Password : ")
    if uid.upper() == "ADMIN":
        if p == "12345":
            print("Login Successfull !")
            AdminMenu()
        else:
            print("Login Fail. Password is wrong.")
    else:
        print("Login Fail. Invalid User ID !!!")            
def create():
    try:
        mydb=mysql.connector.connect(host="localhost",user="root",passwd="")
        cur=mydb.cursor()
        query="create database if not exists cet;"
        cur.execute(query)
        query="use cet ;"
        cur.execute(query)
        query="create table if not exists paper(Qno int primary key, Question varchar(400),option1 varchar(100),option2 varchar(100),option3 varchar(100),option4 varchar(100), answer int);"
        cur.execute(query)
        query="create table if not exists applicant(regno int primary key, name varchar(30), gender set ('m','f'), dob date, address varchar(50), mobile varchar(12), email varchar(40), password varchar(20));"
        cur.execute(query)
        query="create table if not exists quiz(regno int, quizno int, Quizdate date, name varchar(30),score int , result varchar(20),primary key(regno,quizno));"
        cur.execute(query)
    except Exception as E:
        print(E)
        
    
def AdminMenu():
    while True:
        print("*"*80)
        print(" "*25," Smart Quiz Management System (SQMS) ")
        print(" "*20, "Made by :- Ishika Jain (Session: 2020 - 2021) ")
        print("*"*80)
        print(" "*35," ADMIN MENU ")
        print("-"*80)
        print(" 1. Add Question ")
        print(" 2. Search by Question No ")
        print(" 3. Update ")
        print(" 4. Delete Question ")
        print(" 5. Show Marking Scheme ")
        print(" 6. Exit ")
        ch = int(input("Enter the choice : "))
        if ch == 1:
            addQuestion()
        elif ch == 2:
            searchQuestion()
        elif ch == 3:
            updateQuestion()
        elif ch == 4:
            deleteQuestion()
        elif ch == 5:
            showMS()
        elif ch == 6:
            break
        else:
            print("Invalid Choice !")

def StudentMenu():
    while True:
        print("*"*80)
        print(" "*25," Smart Quiz Management System (SQMS) ")
        print(" "*20, "Made by :- Ishika Jain (Session: 2020 - 2021) ")
        print("*"*80)
        print(" "*33,"STUDENT MENU")
        print("-"*80)
        print(" 1. Register ")
        print(" 2. Search ")
        print(" 3. Update ")
        print(" 4. Quiz Start ")
        print(" 5. Quiz Result ")
        print(" 6. Quiz Ranking List ")
        print(" 7. Exit ")
        ch = int(input("Enter the choice : "))
        if ch == 1:
            registerStudent()
        elif ch == 2:
            searchStudent()
        elif ch == 3:
            updateStudent()
        elif ch == 4:
            quizStart()
        elif ch == 5:
            quizResult()
        elif ch == 6:
            quizRanking()
        elif ch == 7:
            break
        else:
            print("Invalid Choice !")

def mainMenu():
    while True:
        print("*"*80)
        print(" "*25," Smart Quiz Management System (SQMS) ")
        print(" "*20, "Made by :- Ishika Jain (Session: 2020 - 2021) ")
        print("*"*80)
        print(" "*35," MAIN MENU ")
        print("-"*80)
        print(" 1. Administrator Menu ")
        print(" 2. Student Menu ")
        print(" 3. Exit ")
        ch = int(input("Enter the choice : "))
        if ch == 1:
            Password()
        elif ch == 2:
            StudentMenu()
        elif ch == 3:
            break
        else:
            print("Invalid Choice !")
create()
mainMenu()
