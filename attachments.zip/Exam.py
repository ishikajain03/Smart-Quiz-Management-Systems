# Exam Module
import mysql.connector
import datetime
def date():
    x = datetime.datetime.now()
    y = str(x)
    print("Quiz Date : ",y[:10])
    return y[:10]
Question = []

def Guess():
    global Question
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
    cur = mydb.cursor()    
    cur.execute("Select count(*) From Paper")
    data = cur.fetchone()
    if data[0] == None:
        print("Question not exist. Please Store the Questions.")
        return 0
    else:
        s = int(data[0])
    A = [i for i in range(1,s+1,1)]
    import random
    N = 1
    B = []
    while N <= 5:
        x = random.choice(A)
        if x not in B:
            B.append(x)
            N += 1
    return B
def loadQuestion():
    global Question
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
    cur = mydb.cursor()    
    qset = Guess()
    for i in range(len(qset)):
        query = "Select * from Paper Where Qno ="+str(qset[i])
        cur.execute(query)
        d = cur.fetchone()
        Question.append(d)
    
    
def quizStart():
    try:
        loadQuestion()
        mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
        cur = mydb.cursor()
        
        global Question
        score = 0
        Regno = input("Enter Registration Number : ")
        p = input("Enter Password : ")
        query = "Select Name From Applicant Where Regno = "+Regno+" And Password='"+p+"'"
        cur.execute(query)
        d = cur.fetchall()
        if d == []:
            print("Please Register/Valid Id and Password and then Attempt the Quiz !")
            return
        else:
            name = str(d[0][0])
            
        qdate = date()
        
        N = len(Question)
        for i in range(N):
            print("Question No. : ",i+1)
            print("Question : ",Question[i][1])
            print("Option 1 : ",Question[i][2])
            print("Option 2 : ",Question[i][3])
            print("Option 3 : ",Question[i][4])
            print("Option 4 : ",Question[i][5])
            ans = int(input("Enter Correct :[1-4] No Answer :  "))
            if ans == 0:
                pass
            elif ans == int(Question[i][6]): # Each Correct answer 4 Marks
                score += 4
            else:
                score -= 1    # Each Wrong Answer Minus 1
        qual = N * 2
        if score >= qual:
            result="Pass"
        else:
            result="Fail"
        cur.execute("Select Max(Quizno) From Quiz Where Regno="+Regno)
        data = cur.fetchall()
        if data[0][0] == None:
            Quizno = 1
        else:
            Quizno = int(data[0][0])+1
        query = "Insert Into Quiz Values("+Regno+","+str(Quizno)+",'"+qdate+"','"+name+"',"+str(score)+",'"+result+"')"
        cur.execute(query)
        mydb.commit()
        print("Registration No : ",Regno)
        print("Quiz No.        : ",Quizno)
        print("Name            : ",name)
        print("Score           : ",score)
        print("Result is       : ",result)
    except Exception as e:
        print("Error is : ",e)
        
def quizResult():
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
    cur = mydb.cursor()
    regno=input("Enter the Registration No. : ")    
    query="Select * from Quiz Where Regno="+regno
    cur.execute(query)
    data = cur.fetchall()
    
    if data == []:
        print("Record Not Found !")
    else:
        print("-"*110)
        for i in range(len(data)):
            print("Quiz No. : ",data[i][1],end ="\t")
            print("Date : ",data[i][2],end ="\t")            
            print("Name : ",data[i][3],end="\t")
            print("Score : ",data[i][4],end="\t")
            print("Result : ",data[i][5])
        print("-"*110)
    
def quizRanking():
    mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
    cur = mydb.cursor()
    query="Select * from quiz order by score desc,regno"
    cur.execute(query)
    data=cur.fetchall()
    if data == []:
        print("Record Not Found !")
    else:
        print("-"*110)
        for i in range(len(data)):
            print("Reg No. : ",data[i][0],end ="\t")
            print("Quiz No. : ",data[i][1],end ="\t")
            print("Date : ",data[i][2],end ="\t")            
            print("Name : ",data[i][3],end="\t")
            print("Score : ",data[i][4],end="\t")
            print("Result : ",data[i][5])
        print("-"*110)

    
