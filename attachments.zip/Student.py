# Student Module
import mysql.connector
def datecheck(dob):
    if not dob[2:4].isdigit():
        dd = dob[0:2]
        mm = dob[3:5]
        yy = dob[6:]
        dob = yy+"-"+mm+"-"+dd
    return dob
def registerStudent():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
        cur = mydb.cursor()
        query = "Select Max(Regno) From Applicant"
        cur.execute(query)
        data = cur.fetchall()
        if data[0][0] == None:
            regno = 1
        else:
            regno = int(data[0][0]) + 1
        while True:
            print("regestration no. : ",regno)
            Name = input("Enter Candidate Name : ")
            gender = input("Enter GENDER : [M/F] ")
            if len(gender) > 1:
                gender = gender[0].upper()
            dob = input("Enter Data of Birth : ")
            dob = datecheck(dob)
            address = input("Enter your Address : ")
            mobile = input("Enter Phone No : ")
            email = input("Enter E-Mail ID : ")
            password = input("Enter your password : ")                  

            query = "Insert Into Applicant Values("+str(regno)+",'"+Name+"','"+gender+"','"+dob+"','"+address+"','"+mobile+"','"+email+"','"+password+"')"
            cur.execute(query)  
            mydb.commit()
            print("Record Insert Successfully !!!")
            ch = input("Add more record? (y/n) : ")
            if ch in "nN":
                break
            else:
                regno += 1
    except Exception as e:
        print("Error is : ",e)
def searchStudent():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='CET')
        cur = mydb.cursor()
        regno=input("Enter Registration No. : ")
        p = input("Enter Password : ")
        query="Select * from Applicant where regno="+regno+" And PAssword ='"+p+"'"
        cur.execute(query)
        data=cur.fetchall()
        if data==[]:
            print(regno," Not Exist in Table")
        else:
            print("Registration No. : ",data[0][0])
            print("Name is          : ",data[0][1])
            print("Gender           : ",data[0][2])
            print("DOB              : ",data[0][3])
            print("Address          : ",data[0][4])
            print("Mobile No.       : ",data[0][5])
            print("Email            : ",data[0][6])
            print("Password         : ",data[0][7])

    except Exception as e:
        print("Error is : ",e)
            
def updateStudent():
    try:
        mydb = mysql.connector.connect(host='localhost', user='root', passwd='', database='cet')
        mycursor = mydb.cursor()

        regno = input("Enter Registration Number to be update : ")
        p = input("Enter Password : ")
        query = "Select * From Applicant Where Regno = "+regno+" And Password='"+p+"'"

        mycursor.execute(query)
        data = mycursor.fetchall()

        found = False
        if data == []:
            print("Record not Found !")
        else:
            Name = str(data[0][1])
            Gender =str(data[0][2])
            DOB = str(data[0][3])
            Address = str(data[0][4])
            Mobile = str(data[0][5])
            Email = str(data[0][6])
            password = str(data[0][7])
            found = True

        if found:
            while True:
                print("Name     : ",Name)
                print("Gender   : ",Gender)
                print("DOB      : ",DOB)
                print("Address  : ",Address)
                print("Mobile   : ",Mobile)
                print("Email    : ",Email)
                print("password : ",password)
                
                print("Edit : 1.Name 2.DOB  3.Address 4.Mobile 5.Email 6.Password 7.No more Edit ")
                ch = int(input("Enter the choice : "))
                if ch == 1:
                    Name = input("Enter Name : ")
                elif ch == 2:
                    DOB = input("Enter DOB : ")
                elif ch == 3:
                    Address = input("Enter Address : ")
                elif ch == 4:
                    Mobile = input("Enter Mobile : ")
                elif ch == 5:
                    Email = input("Enter Email : ")
                elif ch == 6:
                    password = input("Enter password : ")
                elif ch == 7:
                    break
                else:
                    print("Invalid Choice !!!")
            query = "Update Applicant Set Name='"+Name+"',DOB ='"+DOB
            query +="', Address='"+Address+"', Mobile = '"+Mobile+"', Email ='"+Email+"', password ='"+password
            query += "' Where Regno = "+regno
            mycursor.execute(query)
            mydb.commit()
            print("Update Successfully !!!")
    except Exception as e:
        print("Error is : ",e)
    
